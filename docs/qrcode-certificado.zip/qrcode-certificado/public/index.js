const campoModo = document.getElementById("modo");
const blocoCertificado = document.getElementById("bloco-certificado");
const blocoLivre = document.getElementById("bloco-livre");
const campoNome = document.getElementById("nome");
const campoSenha = document.getElementById("senha");
const campoBase = document.getElementById("base");
const campoTexto = document.getElementById("texto");
const botaoGerar = document.getElementById("gerar");
const botaoBaixar = document.getElementById("baixar");
const areaResultado = document.getElementById("resultado");
const areaQr = document.getElementById("qrcode");
const linkUrl = document.getElementById("url");
const erro = document.getElementById("erro");
const aviso = document.getElementById("aviso");

campoBase.value = location.origin;

// Se o painel foi aberto como "localhost", o celular não consegue acessar o link do QR.
if (["localhost", "127.0.0.1"].includes(location.hostname)) {
  aviso.textContent =
    "Atenção: você abriu o painel como 'localhost'. O celular não acessa esse endereço. " +
    "No modo certificado, troque o 'Endereço do servidor' pelo IP que aparece no terminal (ex.: http://192.168.0.10:3000).";
}

campoModo.addEventListener("change", () => {
  const livre = campoModo.value === "livre";
  blocoCertificado.hidden = livre;
  blocoLivre.hidden = !livre;
  areaResultado.hidden = true;
  erro.textContent = "";
});

function mostrarQR(conteudo) {
  QRLocal.desenhar(areaQr, conteudo, { tamanho: 256, cor: "#1b1f3b", nivel: "M", margem: 1 });
  linkUrl.textContent = conteudo;
  // só vira link clicável se for http/https (evita executar outros esquemas no painel)
  if (/^https?:\/\//i.test(conteudo)) {
    linkUrl.href = conteudo;
  } else {
    linkUrl.removeAttribute("href");
  }
  areaResultado.hidden = false;
}

async function gerarCertificado() {
  const nome = campoNome.value.trim();
  const base = campoBase.value.trim().replace(/\/+$/, "");

  if (!nome) {
    erro.textContent = "Digite o nome do candidato.";
    return;
  }
  if (!/^https?:\/\/.+/i.test(base)) {
    erro.textContent = "O endereço do servidor deve começar com http:// ou https://";
    return;
  }

  const resposta = await fetch("/api/gerar", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-senha": encodeURIComponent(campoSenha.value),
    },
    body: JSON.stringify({ nome }),
  });

  if (resposta.status === 401) {
    erro.textContent = "Senha incorreta. Use a senha que aparece no terminal.";
    return;
  }
  if (!resposta.ok) throw new Error("Falha " + resposta.status);

  const { token } = await resposta.json();
  mostrarQR(base + "/baixar/" + token);
}

function gerarLivre() {
  const texto = campoTexto.value.trim();
  if (!texto) {
    erro.textContent = "Digite um link ou texto.";
    return;
  }
  mostrarQR(texto);
}

async function aoGerar() {
  erro.textContent = "";
  areaResultado.hidden = true;
  botaoGerar.disabled = true;
  try {
    if (campoModo.value === "livre") gerarLivre();
    else await gerarCertificado();
  } catch (e) {
    erro.textContent = "Não foi possível gerar. Se for o modo certificado, o servidor (node server.js) está rodando? Se for texto, ele pode ser longo demais.";
    areaResultado.hidden = true;
    console.error(e);
  } finally {
    botaoGerar.disabled = false;
  }
}

function aoBaixar() {
  const canvas = areaQr.querySelector("canvas");
  if (!canvas) return;
  const base = campoModo.value === "livre" ? "qrcode" : "qr_" + campoNome.value.trim().replace(/[^\w\-]+/g, "_");
  const link = document.createElement("a");
  link.download = base + ".png";
  link.href = canvas.toDataURL("image/png");
  link.click();
}

botaoGerar.addEventListener("click", aoGerar);
botaoBaixar.addEventListener("click", aoBaixar);
[campoNome, campoSenha, campoBase, campoTexto].forEach((c) =>
  c.addEventListener("keydown", (e) => { if (e.key === "Enter") aoGerar(); })
);
