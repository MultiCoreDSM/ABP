// Servidor do QR Code de certificados. Não precisa instalar nenhuma biblioteca (npm).
// Rodar:  node server.js
const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");

const PORTA = Number(process.env.PORT) || 3000;
const PASTA_PUBLICA = path.join(__dirname, "public");
const PASTA_ARQUIVOS = path.join(__dirname, "arquivos");
const ARQUIVO_TOKENS = path.join(__dirname, "tokens.json");

// Senha do painel (quem gera os QR Codes). Defina com ADMIN_SENHA, ou uma é sorteada a cada início.
const SENHA = process.env.ADMIN_SENHA || crypto.randomBytes(4).toString("hex");

const TIPOS = {
  ".apk": "application/vnd.android.package-archive",
  ".pdf": "application/pdf",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".zip": "application/zip",
};
const ESTATICOS = {
  "/": ["index.html", "text/html; charset=utf-8"],
  "/index.html": ["index.html", "text/html; charset=utf-8"],
  "/index.css": ["index.css", "text/css; charset=utf-8"],
  "/index.js": ["index.js", "application/javascript; charset=utf-8"],
  "/qrcode.js": ["qrcode.js", "application/javascript; charset=utf-8"],
};

// ---- tokens salvos em tokens.json (sobrevivem ao reiniciar o servidor) ----
let tokens = {};
try {
  tokens = JSON.parse(fs.readFileSync(ARQUIVO_TOKENS, "utf8"));
} catch (e) {
  tokens = {};
}
function salvarTokens() {
  fs.writeFileSync(ARQUIVO_TOKENS, JSON.stringify(tokens, null, 2));
}

function senhaCorreta(recebida) {
  const a = crypto.createHash("sha256").update(String(recebida || "")).digest();
  const b = crypto.createHash("sha256").update(SENHA).digest();
  return crypto.timingSafeEqual(a, b);
}

// Acha o arquivo do certificado dentro da pasta "arquivos"
function acharArquivo() {
  if (!fs.existsSync(PASTA_ARQUIVOS)) return null;
  const nomes = fs.readdirSync(PASTA_ARQUIVOS).filter((n) => TIPOS[path.extname(n).toLowerCase()]);
  return nomes.length ? path.join(PASTA_ARQUIVOS, nomes[0]) : null;
}


function escaparHtml(t) {
  return String(t).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function formatarTamanho(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / 1024 / 1024).toFixed(1) + " MB";
}

// Página que o candidato vê ao escanear o QR Code
function paginaDownload(registro, token, arquivo) {
  const ext = path.extname(arquivo).toLowerCase();
  const dica = ext === ".apk"
    ? '<p class="dica">Este arquivo é um app Android (APK). Ao baixar, o Android pode pedir para permitir a instalação de apps desconhecidos.</p>'
    : "";
  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Seu certificado</title>
<style>
  * { box-sizing: border-box; }
  body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 1rem;
         background: #eef1f8; color: #1b1f3b; font-family: system-ui, -apple-system, "Segoe UI", sans-serif; }
  .card { width: 100%; max-width: 420px; background: #fff; border: 1px solid #cfd5e8; border-radius: 16px;
          padding: 2rem; text-align: center; }
  .icone { font-size: 3rem; margin-bottom: .5rem; }
  h1 { margin: 0 0 .5rem; font-size: 1.5rem; }
  p { margin: .5rem 0; color: #5d6384; }
  .nome { color: #1b1f3b; font-weight: 700; font-size: 1.15rem; }
  .arquivo { font-size: .85rem; word-break: break-all; }
  a.botao { display: block; margin-top: 1.5rem; padding: 1rem; border-radius: 12px; background: #3a4bd6;
            color: #fff; font-size: 1.1rem; font-weight: 700; text-decoration: none; }
  .dica { font-size: .8rem; color: #8a5a00; margin-top: 1rem; }
</style>
</head>
<body>
  <main class="card">
    <div class="icone">🎓</div>
    <h1>Parabéns!</h1>
    <p class="nome">${escaparHtml(registro.nome)}</p>
    <p>Seu certificado está pronto para download.</p>
    <p class="arquivo">${escaparHtml(path.basename(arquivo))} · ${formatarTamanho(fs.statSync(arquivo).size)}</p>
    <a class="botao" href="/arquivo/${token}">Baixar certificado</a>
    ${dica}
  </main>
</body>
</html>`;
}

function responder(res, status, corpo, tipo) {
  res.writeHead(status, { "Content-Type": tipo || "text/plain; charset=utf-8", "Cache-Control": "no-store" });
  res.end(corpo);
}

function lerCorpo(req) {
  return new Promise((resolve, reject) => {
    let dados = "";
    req.on("data", (c) => {
      dados += c;
      if (dados.length > 10000) { reject(new Error("grande")); req.destroy(); }
    });
    req.on("end", () => resolve(dados));
    req.on("error", reject);
  });
}

const servidor = http.createServer(async (req, res) => {
  const caminho = decodeURIComponent(req.url.split("?")[0]);

  // 1) Página do painel e seus arquivos
  if (req.method === "GET" && ESTATICOS[caminho]) {
    const [arquivo, tipo] = ESTATICOS[caminho];
    return fs.readFile(path.join(PASTA_PUBLICA, arquivo), (erro, dados) =>
      erro ? responder(res, 404, "Arquivo não encontrado.") : responder(res, 200, dados, tipo)
    );
  }

  // 2) Gera um token novo para um candidato (precisa da senha)
  if (req.method === "POST" && caminho === "/api/gerar") {
    if (!senhaCorreta(decodeURIComponent(req.headers["x-senha"] || ""))) {
      return responder(res, 401, JSON.stringify({ erro: "senha" }), "application/json");
    }
    try {
      const { nome } = JSON.parse((await lerCorpo(req)) || "{}");
      if (!nome || !String(nome).trim()) {
        return responder(res, 400, JSON.stringify({ erro: "nome" }), "application/json");
      }
      const token = crypto.randomBytes(18).toString("base64url"); // impossível de adivinhar
      tokens[token] = { nome: String(nome).trim().slice(0, 100), criadoEm: new Date().toISOString(), downloads: 0 };
      salvarTokens();
      return responder(res, 200, JSON.stringify({ token }), "application/json");
    } catch (e) {
      return responder(res, 400, JSON.stringify({ erro: "requisicao" }), "application/json");
    }
  }

  // 3) O que o celular abre ao escanear o QR Code: uma página com o botão de baixar
  const pagina = caminho.match(/^\/baixar\/([A-Za-z0-9_-]+)$/);
  if (req.method === "GET" && pagina) {
    const registro = tokens[pagina[1]];
    if (!registro) return responder(res, 404, "Link inválido ou expirado.");
    const arquivo = acharArquivo();
    if (!arquivo) return responder(res, 500, "Nenhum arquivo foi colocado na pasta 'arquivos' do servidor.");
    return responder(res, 200, paginaDownload(registro, pagina[1], arquivo), "text/html; charset=utf-8");
  }

  // 4) O download em si (botão da página acima)
  const baixar = caminho.match(/^\/arquivo\/([A-Za-z0-9_-]+)$/);
  if (req.method === "GET" && baixar) {
    const registro = tokens[baixar[1]];
    if (!registro) return responder(res, 404, "Link inválido ou expirado.");

    const arquivo = acharArquivo();
    if (!arquivo) return responder(res, 500, "Nenhum arquivo foi colocado na pasta 'arquivos' do servidor.");

    const ext = path.extname(arquivo).toLowerCase();
    const nomeFinal = path.basename(arquivo).replace(/[^\w.\- ]/g, "_");
    registro.downloads += 1;
    salvarTokens();

    res.writeHead(200, {
      "Content-Type": TIPOS[ext],
      "Content-Length": fs.statSync(arquivo).size,
      "Content-Disposition": `attachment; filename="${nomeFinal}"`,
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    });
    return fs.createReadStream(arquivo).pipe(res);
  }

  responder(res, 404, "Página não encontrada.");
});

servidor.listen(PORTA, "0.0.0.0", () => {
  console.log("\nServidor rodando.\n");
  console.log("Abra o painel no navegador do computador:");
  console.log(`  http://localhost:${PORTA}   (só para testar no próprio PC)`);
  for (const lista of Object.values(os.networkInterfaces())) {
    for (const i of lista) {
      if (i.family === "IPv4" && !i.internal) {
        console.log(`  http://${i.address}:${PORTA}   <- use este para o QR funcionar no celular (mesmo Wi-Fi)`);
      }
    }
  }
  console.log(`\nSenha do painel: ${SENHA}${process.env.ADMIN_SENHA ? "" : "   (sorteada agora; para fixar uma, use a variável ADMIN_SENHA)"}`);
  const arq = acharArquivo();
  console.log(arq ? `Arquivo que será baixado: ${path.basename(arq)}` : "ATENÇÃO: coloque o arquivo (.apk ou .pdf) na pasta 'arquivos'.");
  console.log("");
});
